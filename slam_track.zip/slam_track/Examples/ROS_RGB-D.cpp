#include "Semantic.h"
#include "System.h"
#include <algorithm>
#include <chrono>
#include <fstream>
#include <iostream>
#include <opencv2/core/core.hpp>
#include <ros/ros.h>
#include <cv_bridge/cv_bridge.h>
#include <message_filters/subscriber.h>
#include <message_filters/time_synchronizer.h>
#include <message_filters/sync_policies/approximate_time.h>

using namespace std;
using namespace ORB_SLAM3;

class ImageGrabber
{
public:
    ImageGrabber(ORB_SLAM3::System* pSLAM):mpSLAM(pSLAM){}

    void GrabRGBD(const sensor_msgs::ImageConstPtr& msgRGB,const sensor_msgs::ImageConstPtr& msgD);

    ORB_SLAM3::System* mpSLAM;
};

int main(int argc, char** argv)
{
    ros::init(argc, argv, "1");
    ros::start();
    ros::NodeHandle nh;

    if (argc < 3) {
        cerr << endl << "Usage: EXE path_to_vocabulary path_to_settings" << endl;
        ros::shutdown();
        return 1;
    }

    std::string cnn_method = "yolov8"; // maskrcnn
    std::string bagfile_name;   //rosbag

    float init_delay = 0.05; //usec
    int init_frames = 2;    //usec
    // delay for each frame
    float frame_delay = 0;

    nh.getParam("cnn_method", cnn_method);
    // control the framerate
    nh.getParam("init_delay", init_delay);
    nh.getParam("frame_delay", frame_delay);
    nh.getParam("init_frames", init_frames);
    // nh.getParam("bagfile_name", bagfile_name);

    // do not save result
    // Config::GetInstance()->IsSaveResult(false);
    
    //保存图片使用
    // Config::GetInstance()->IsSaveResult(true);
    // Config::GetInstance()->createSavePath("/home/plane/zhang");

    Semantic::GetInstance()->SetSemanticMethod(cnn_method);
    

    // Create SLAM system. It initializes all system threads and gets ready to process frames.
    ORB_SLAM3::System SLAM(argv[1], argv[2], ORB_SLAM3::System::RGBD, true);

//     std::thread bag_thread([bagfile_name](){
//     std::string command = "rosbag play --clock " + bagfile_name;
//     system(command.c_str());
// });

    ImageGrabber igb(&SLAM);

    Semantic::GetInstance()->Run();


    message_filters::Subscriber<sensor_msgs::Image> rgb_sub(nh, "/camera/color/image_raw", 100);
    message_filters::Subscriber<sensor_msgs::Image> depth_sub(nh, "/camera/depth/image_raw", 100);
    typedef message_filters::sync_policies::ApproximateTime<sensor_msgs::Image, sensor_msgs::Image> sync_pol;
    message_filters::Synchronizer<sync_pol> sync(sync_pol(10), rgb_sub, depth_sub);
    sync.registerCallback(boost::bind(&ImageGrabber::GrabRGBD, &igb, _1, _2));

    ros::spin();
    // Custom loop with spinOnce
    // ros::Rate loop_rate(30); // Adjust the rate as needed
    // while (ros::ok()) {
    //     ros::spinOnce();
    //     loop_rate.sleep(); // Maintain the loop rate
    // }

    SLAM.SaveTrajectoryTUM("/home/plane/CameraTrajectory.txt");
    SLAM.SaveKeyFrameTrajectoryTUM("/home/plane/KeyFrameTrajectory.txt");


    SLAM.Shutdown();

     //pcl::io::savePCDFileBinary("/home/plane/1/savedMap.pcd", *SLAM.mpPointCloudMapping->GetGlobalMap());

 //   SLAM.SaveTrajectoryTUM("/home/zhang/TUMresult/rgbd_dataset_freiburg3_sitting_halfsphere/BiSeNetV2_SLAM/CameraTrajectory6.txt");
//    SLAM.SaveKeyFrameTrajectoryTUM("/home/zhang/TUMresult/rgbd_dataset_freiburg3_sitting_halfsphere/BiSeNetV2_SLAM/KeyFrameTrajectory6.txt");

    ros::shutdown();

    return 0;
}

void ImageGrabber::GrabRGBD(const sensor_msgs::ImageConstPtr& msgRGB,const sensor_msgs::ImageConstPtr& msgD)
{
    // Copy the ros image message to cv::Mat.
    cv_bridge::CvImageConstPtr cv_ptrRGB;
    try
    {
        // cv_ptrRGB = cv_bridge::toCvShare(msgRGB);
        // 使用rgb8编砝格弝
        cv_ptrRGB = cv_bridge::toCvShare(msgRGB, sensor_msgs::image_encodings::RGB8);
        // 显弝�?杢�?�色空间从RGB到BGR
        cv::cvtColor(cv_ptrRGB->image, cv_ptrRGB->image, cv::COLOR_RGB2BGR);
    }
    catch (cv_bridge::Exception& e)
    {
        ROS_ERROR("cv_bridge exception: %s", e.what());
        return;
    }

    cv_bridge::CvImageConstPtr cv_ptrD;
    try
    {
        cv_ptrD = cv_bridge::toCvShare(msgD);
    }
    catch (cv_bridge::Exception& e)
    {
        ROS_ERROR("cv_bridge exception: %s", e.what());
        return;
    }
    // ROS_INFO("Received image with encoding: %s", msgRGB->encoding.c_str());
    // ROS_INFO("Received image_depth with encoding: %s", msgD->encoding.c_str());
    mpSLAM->TrackRGBD(cv_ptrRGB->image, cv_ptrD->image, cv_ptrRGB->header.stamp.toSec());
    

}
